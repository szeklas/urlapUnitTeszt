function IgazitoDivClassEllenorzes() {
    let tesztElem = document.querySelector("div")
    if (tesztElem.classList == "container") {
        teszt01.innerHTML = "Teszt 01 sikeres"
    }
    else {
        teszt01.innerHTML = "Teszt 01 sikertelen"
    }
}
IgazitoDivClassEllenorzes()



function CimsorTartalmaTeszt() {
    let tesztElem = document.querySelector("h1")
    if (tesztElem.textContent == "Tanfolyam regisztráció") {
        teszt02.innerHTML = "Teszt 02 sikeres"
    }
    else {
        teszt02.innerHTML = "Teszt 02 sikertelen"
    }
}
CimsorTartalmaTeszt()



function ElsoInputTipusa() {
    let tesztElem = document.querySelector("input")
    if (tesztElem.type == "text") {
        teszt03.innerHTML = "Teszt 03 sikeres"
    }
    else {
        teszt03.innerHTML = "Teszt 03 sikertelen"
    }
}
ElsoInputTipusa()



function ElsoInputAzonositoja() {
    let tesztElem = document.querySelector("input")
    if (tesztElem.id == "veznev") {
        teszt04.innerHTML = "Teszt 04 sikeres"
    }
    else {
        teszt04.innerHTML = "Teszt 04 sikertelen"
    }
}
ElsoInputAzonositoja()



function ElsoInputBootstrapOsztalya() {
    let tesztElem = document.querySelector("input")
    if (tesztElem.classList == "form-control") {
        teszt05.innerHTML = "Teszt 05 sikeres"
    }
    else {
        teszt05.innerHTML = "Teszt 05 sikertelen"
    }
}
ElsoInputBootstrapOsztalya()



function MasodikInputTipusa() {
    let tesztElem = document.querySelectorAll("input")
    if (tesztElem[1].type == "text") {
        teszt06.innerHTML = "Teszt 06 sikeres"
    }
    else {
        teszt06.innerHTML = "Teszt 06 sikertelen"
    }
}
MasodikInputTipusa()



function MasodikInputAzonositoja() {
    let tesztElem = document.querySelectorAll("input")
    if (tesztElem[1].id == "kernev") {
        teszt07.innerHTML = "Teszt 07 sikeres"
    }
    else {
        teszt07.innerHTML = "Teszt 07 sikertelen"
    }
}
MasodikInputAzonositoja()



function MasodikInputBootstrapOsztalya() {
    let tesztElem = document.querySelectorAll("input")
    if (tesztElem[1].classList == "form-control") {
        teszt08.innerHTML = "Teszt 08 sikeres"
    }
    else {
        teszt08.innerHTML = "Teszt 08 sikertelen"
    }
}
MasodikInputBootstrapOsztalya()



function HarmadikInputTipusa() {
    let tesztElem = document.querySelectorAll("input")
    if (tesztElem[2].type == "text") {
        teszt09.innerHTML = "Teszt 09 sikeres"
    }
    else {
        teszt09.innerHTML = "Teszt 09 sikertelen"
    }
}
HarmadikInputTipusa()



function HarmadikInputAzonositoja() {
    let tesztElem = document.querySelectorAll("input")
    if (tesztElem[2].id == "fnev") {
        teszt10.innerHTML = "Teszt 10 sikeres"
    }
    else {
        teszt10.innerHTML = "Teszt 10 sikertelen"
    }
}
HarmadikInputAzonositoja()



function HarmadikInputBootstrapOsztalya() {
    let tesztElem = document.querySelectorAll("input")
    if (tesztElem[2].classList == "form-control") {
        teszt11.innerHTML = "Teszt 11 sikeres"
    }
    else {
        teszt11.innerHTML = "Teszt 11 sikertelen"
    }
}
HarmadikInputBootstrapOsztalya()



function NegyedikInputTipusa() {
    let tesztElem = document.querySelectorAll("input")
    if (tesztElem[3].type == "password") {
        teszt12.innerHTML = "Teszt 12 sikeres"
    }
    else {
        teszt12.innerHTML = "Teszt 12 sikertelen"
    }
}
NegyedikInputTipusa()



function NegyedikInputAzonositoja() {
    let tesztElem = document.querySelectorAll("input")
    if (tesztElem[3].id == "pass1") {
        teszt13.innerHTML = "Teszt 13 sikeres"
    }
    else {
        teszt13.innerHTML = "Teszt 13 sikertelen"
    }
}
NegyedikInputAzonositoja()



function NegyedikInputBootstrapOsztalya() {
    let tesztElem = document.querySelectorAll("input")
    if (tesztElem[3].classList == "form-control") {
        teszt14.innerHTML = "Teszt 14 sikeres"
    }
    else {
        teszt14.innerHTML = "Teszt 14 sikertelen"
    }
}
NegyedikInputBootstrapOsztalya()



function OtodikkInputTipusa() {
    let tesztElem = document.querySelectorAll("input")
    if (tesztElem[4].type == "password") {
        teszt15.innerHTML = "Teszt 15 sikeres"
    }
    else {
        teszt15.innerHTML = "Teszt 15 sikertelen"
    }
}
OtodikkInputTipusa()



function OtodikInputAzonositoja() {
    let tesztElem = document.querySelectorAll("input")
    if (tesztElem[4].id == "pass2") {
        teszt16.innerHTML = "Teszt 16 sikeres"
    }
    else {
        teszt16.innerHTML = "Teszt 16 sikertelen"
    }
}
OtodikInputAzonositoja()



function OtodikInputBootstrapOsztalya() {
    let tesztElem = document.querySelectorAll("input")
    if (tesztElem[4].classList == "form-control") {
        teszt17.innerHTML = "Teszt 17 sikeres"
    }
    else {
        teszt17.innerHTML = "Teszt 17 sikertelen"
    }
}
OtodikInputBootstrapOsztalya()



function HatodikInputTipusa() {
    let tesztElem = document.querySelectorAll("input")
    if (tesztElem[5].type == "email") {
        teszt18.innerHTML = "Teszt 18 sikeres"
    }
    else {
        teszt18.innerHTML = "Teszt 18 sikertelen"
    }
}
HatodikInputTipusa()



function HatodikInputAzonositoja() {
    let tesztElem = document.querySelectorAll("input")
    if (tesztElem[5].id == "email") {
        teszt19.innerHTML = "Teszt 19 sikeres"
    }
    else {
        teszt19.innerHTML = "Teszt 19 sikertelen"
    }
}
HatodikInputAzonositoja()



function HatodikInputBootstrapOsztalya() {
    let tesztElem = document.querySelectorAll("input")
    if (tesztElem[5].classList == "form-control") {
        teszt20.innerHTML = "Teszt 20 sikeres"
    }
    else {
        teszt20.innerHTML = "Teszt 20 sikertelen"
    }
}
HatodikInputBootstrapOsztalya()



function HetedikInputTipusa() {
    let tesztElem = document.querySelectorAll("input")
    if (tesztElem[6].type == "tel") { // A 21-es feladatnál amit írtál a mező típusánál "tel" szerepel, viszont a html fájlban a típusa "text", ezért sikertelen ez a teszt, gondoltam inkább nem írom át. 
                                        //Esetleges elírás történt gondolom vagy a html fájlban, vagy a feladatsorban
        teszt21.innerHTML = "Teszt 21 sikeres"
    }
    else {
        teszt21.innerHTML = "Teszt 21 sikertelen"
    }
}
HetedikInputTipusa()



function HetedikInputAzonositoja() {
    let tesztElem = document.querySelectorAll("input")
    if (tesztElem[6].id == "tel") {
        teszt22.innerHTML = "Teszt 22 sikeres"
    }
    else {
        teszt22.innerHTML = "Teszt 22 sikertelen"
    }
}
HetedikInputAzonositoja()



function HetedikInputBootstrapOsztalya() {
    let tesztElem = document.querySelectorAll("input")
    if (tesztElem[6].classList == "form-control") {
        teszt23.innerHTML = "Teszt 23 sikeres"
    }
    else {
        teszt23.innerHTML = "Teszt 23 sikertelen"
    }
}
HetedikInputBootstrapOsztalya()



function ElsoLabelTartalma(){
    let tesztElem=document.querySelector("label")
    if(tesztElem.textContent=="Vezeték név:"){
        teszt24.innerHTML="Teszt 24 sikeres"
    }
    else{
        teszt24.innerHTML="Teszt 24 sikertelen"
    }
}
ElsoLabelTartalma()



function MasodikLabelTartalma(){
    let tesztElem=document.querySelectorAll("label")
    if(tesztElem[1].textContent=="Kereszt név:"){
        teszt25.innerHTML="Teszt 25 sikeres"
    }
    else{
        teszt25.innerHTML="Teszt 25 sikertelen"
    }
}
MasodikLabelTartalma()



function HarmadikLabelTartalma(){
    let tesztElem=document.querySelectorAll("label")
    if(tesztElem[2].textContent=="Felhasználói név:"){
        teszt26.innerHTML="Teszt 26 sikeres"
    }
    else{
        teszt26.innerHTML="Teszt 26 sikertelen"
    }
}
HarmadikLabelTartalma()



function NegyedikLabelTartalma(){
    let tesztElem=document.querySelectorAll("label")
    if(tesztElem[3].textContent=="Jelszó:"){
        teszt27.innerHTML="Teszt 27 sikeres"
    }
    else{
        teszt27.innerHTML="Teszt 27 sikertelen"
    }
}
NegyedikLabelTartalma()



function OtodikLabelTartalma(){
    let tesztElem=document.querySelectorAll("label")
    if(tesztElem[4].textContent=="Jelszó ismét:"){
        teszt28.innerHTML="Teszt 28 sikeres"
    }
    else{
        teszt28.innerHTML="Teszt 28 sikertelen"
    }
}
OtodikLabelTartalma()



function HatodikLabelTartalma(){
    let tesztElem=document.querySelectorAll("label")
    if(tesztElem[5].textContent=="E-mail cím:"){
        teszt29.innerHTML="Teszt 29 sikeres"
    }
    else{
        teszt29.innerHTML="Teszt 29 sikertelen"
    }
}
HatodikLabelTartalma()



function HetedikLabelTartalma(){
    let tesztElem=document.querySelectorAll("label")
    if(tesztElem[6].textContent=="Telefonszám:"){
        teszt30.innerHTML="Teszt 30 sikeres"
    }
    else{
        teszt30.innerHTML="Teszt 30 sikertelen"
    }
}
HetedikLabelTartalma()



function NyolcadikLabelTartalma(){
    let tesztElem=document.querySelectorAll("label")
    if(tesztElem[7].textContent=="Tanfolyam típusa:"){
        teszt31.innerHTML="Teszt 31 sikeres"
    }
    else{
        teszt31.innerHTML="Teszt 31 sikertelen"
    }
}
NyolcadikLabelTartalma()



function KilencedikLabelTartalma(){
    let tesztElem=document.querySelectorAll("label")
    if(tesztElem[8].textContent=="Adatvédelmi nyilatkozat elfogadása"){
        teszt32.innerHTML="Teszt 32 sikeres"
    }
    else{
        teszt32.innerHTML="Teszt 32 sikertelen"
    }
}
KilencedikLabelTartalma()



function ElsoSmallTagOsztalyokEsTartalma(){
    let tesztElem=document.querySelector("small")
    if(tesztElem.classList=="form-text text-muted" && 
        tesztElem.textContent=="Beceneve, mely mások számára is látható."){
        teszt33.innerHTML="Teszt 33 sikeres"
    }
    else{
        teszt33.innerHTML="Teszt 33 sikertelen"
    }
}
ElsoSmallTagOsztalyokEsTartalma()



function MasodikSmallTagOsztalyokEsTartalma(){
    let tesztElem=document.querySelectorAll("small")
    if(tesztElem[1].classList=="form-text text-muted" && 
        tesztElem[1].textContent=="Ide továbbítjuk a legfontosabb tanfolyam információkat önnek."){
        teszt34.innerHTML="Teszt 34 sikeres"
    }
    else{
        teszt34.innerHTML="Teszt 34 sikertelen"
    }
}
MasodikSmallTagOsztalyokEsTartalma()



function GombBootstrapOsztalyaEsTartalma(){
    let tesztElem=document.querySelector("button")
    if(tesztElem.classList=="btn btn-primary w-100" && tesztElem.textContent=="Regisztrálok"){
        teszt35.innerHTML="Teszt 35 sikeres"
    }
    else{
        teszt35.innerHTML="Teszt 35 sikertelen"
    }
}
GombBootstrapOsztalyaEsTartalma()



function SelectMezoElemekSzama(){
    let tesztElem=document.querySelectorAll("select option")
    if(tesztElem.length==4){
        teszt36.innerHTML="Teszt 36 sikeres"
    }
    else{
        teszt36.innerHTML="Teszt 36 sikertelen"
    }
}
SelectMezoElemekSzama()



function SelectMezoElemErteke(){
    let tesztElem=document.querySelector("option")
    if(tesztElem.selected=="selected"){ // Erre nem jöttem rá
        teszt37.innerHTML="Teszt 37 sikeres"
    }
    else{
        teszt37.innerHTML="Teszt 37 sikertelen"
        teszt37.style="color: red"
    }
}
SelectMezoElemErteke()